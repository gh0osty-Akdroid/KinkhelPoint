const db = require("../../config/db")
const { createUser, User } = require("../../models/User")
const Session = require("../../models/Session")
const responses = require("../../utilities/responses")
const jwt = require('jsonwebtoken');
const Randomstring = require('randomstring')
const bcrypt = require('bcrypt');
const { createOTPtoken, Verification, createEmailtoken } = require("../../models/Verification");
const { generateCode } = require("../../utilities/random");


const generateAcessToken = async (user) => {
    const jwtToken = await jwt.sign(
        { id: user.id, phone: user.phone },
        process.env.JWTACESSSECRET,
        { expiresIn: 86400000 }
    );
    return jwtToken
}



exports.Login = async (req, res) => {
    const { phone, password } = req.body
    try {
        const user = await User.findOne({ where: { phone: phone } })
        await bcrypt.compare(password, user.password, async function (err, result) {
            if (result === true) createOTPtoken(user, res)
            else return responses.notFoundError(res, "User with these credentials cannot be found.")
        })
    } catch (err) {
        return responses.notFoundError(res, err)
    }

}


exports.LoginVerification = async (req, res) => {
    const phone = req.params.email
    const otp = req.body.otp
    await User.findOne({ where: { phone: phone } }).then(async (user) => {
        Verification.findOne({ where: { user_id: user.id, is_email:false } }).then(async (data) => {
            if (data.token === otp) {
                const acessToken = await generateAcessToken(user)
                responses.dataSuccess(res, { user: user, jwtToken: acessToken })
            }
            else responses.validatonError(res, "Token is either expired or not found.")
        })
    }).catch(() => { responses.notFoundError(res, err) })
}

exports.ResendLoginOtp = async (req, res) => {
    const email = req.params.email
    await User.findOne({ where: { phone: email } }).then(async(user)=>{
        await createOTPtoken(user, res)
    })
    
}

exports.Register = async (req, res) => {
    const body = req.body
    const result = await createUser(res, body)
    return responses.blankSuccess(res)
}

exports.otpVerify = async (req, res) => {
    const body = req.body
    await Verification.findOne({ where: { user_id: body.user_id, token: body.token } }).then(v => {
        if (!v) responses.notFoundError(res, "The Token Cannot Be Verified. Please Try Again.")
        else responses.blankSuccess(res)
    })
}

exports.resendOtp = async (req, res) => {
    const user_id = req.params.user_id
    await Verification.findOne({ where: { user_id: user_id } }).then(async v => {
        if (v) {
            await v.destroy().then(() => createPhoneToken(user_id, res)).catch(err => responses.serverError(res, err))
        }
        else createPhoneToken(user_id, res)
    })
}

const createPhoneToken = async (id, res) => {
    const token = Verification.build({
        'user_id': id,
        'token': 123456,
        "is_email": false
    })

    await token.save().then(() => {
        return responses.blankSuccess(res)
    }).catch(err => console.log(err))
}


exports.emailVerification = async (req, res) => {
    const email = req.params.email
    const vCode = req.params.vCode;
    User.findOne({ where: { email: email } }).then(async (user) => {
        if (user.email_verified) responses.dataSuccess(res, "The email has already been verified.")
        Verification.findOne({ where: { user_id: user.id }, order: [['createdAt', 'DESC']] }).then(async (data) => {
            if (data.token === vCode && data.is_email) {
                responses.blankSuccess(res)
            }
            else responses.validatonError(res, "Token is either expired or not found.")
        })
    }).catch((err) => {
        responses.notFoundError(res, "User Not Found with given email")
    })
}

exports.NewEmailVerificationLink = async (req, res) => {
    const email = req.params.email
    await User.findOne({ where: { email: email } }).then((data) => {
        if (data.email_verified) responses.blankSuccess(res)
        createEmailtoken(data, res)
        responses.dataSuccess(res, "Email with new link has been sent")
    })
}

