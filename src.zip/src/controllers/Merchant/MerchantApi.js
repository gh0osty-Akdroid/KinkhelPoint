exports.getvalues =  async (req, res) =>{
    const data = req.query
}