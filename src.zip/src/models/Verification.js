const { STRING, BOOLEAN, INTEGER, DOUBLE, TEXT, BIGINT } = require('sequelize')
const Sequelize = require('sequelize')
const db = require('../config/db')
const { sendEmail } = require('../utilities/mailer')
const sendOTP = require('../utilities/otpHandler')
const { generateToken, generateCode, generateId } = require('../utilities/random')
const { validatonError, blankSuccess, serverError, dataSuccess } = require('../utilities/responses')

const Verification = db.define('verifications', {
    id: {
        type: BIGINT,
        autoIncrement: true,
        primaryKey: true
    },
    user_id: {
        allowNull: false,
        type: INTEGER,
        references: {
            model: 'users',
            key: 'id'
        }
    },
    token: {
        allowNull: false,
        type: STRING,
        unique: false
    },
    is_email: {
        defaultValue: true,
        type: BOOLEAN
    }
}, {
    tableName: 'verifications'
})

Verification.sync({ alter: false })

const createOTPtoken = async (user, res) => {
    const checkToken = await Verification.findOne({ where: { user_id: user.id, is_email:false } })
    if (checkToken) {
        await checkToken.destroy().then(() => createPhoneToken(user, res)).catch(err => console.log(err))
    }
    else createPhoneToken(user, res)
}

const createPhoneToken = async (user, res) => {
    const OTP = generateToken()
    const token = Verification.build({
        'user_id': user.id,
        'token': OTP,
        "is_email": false
    })

    await token.save().then(async() => {
        await sendOTP(user.phone, `Your Verification Code is ${OTP}`)
        return dataSuccess(res, user)
    }).catch(err => console.log(err))
}

const createEmailtoken = async (user, res) => {
    try {
        const transaction = await db.transaction()
        const token = await Verification.build({
            'user_id': user.id,
            'token': generateCode(),
            "is_email": true
        }, { transaction })

        await transaction.afterCommit(async () => {
            token.id = generateId()
            token.save()
            const data = await ejs.renderFile(__dirname + "/../../src/public/views/welcomeMail.ejs", { name: user.name, site: process.env.APP_URL, token: vCode })
            await sendEmail(user.email, "Welcome!", data)

        })
        await transaction.commit()
    }
    catch (err) {
        return console.log(err)
    }
}







module.exports = { Verification, createEmailtoken, createOTPtoken }