exports.AdminMiddleware = async(req, res, next) =>{
    next
}


exports.UserMiddleware = async(req, res, next) =>{
    
    next

}